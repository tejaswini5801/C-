// using System;

// namespace MyApplication
// {
//   class Test
//   {
//     static void Main(string[] args)
//     {
//       for (int i = 0; i < 5; i++) 
//       {
//         Console.WriteLine(i);
//       }    
//     }
//   }
// }