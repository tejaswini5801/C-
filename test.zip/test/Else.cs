// using System;

// namespace MyApplicationn
// {
//   class Else
//   {
//     static void Main(string[] args)
//     {
//       int time = 20;
//       if (time < 18) 
//       {
//         Console.WriteLine("Good day.");
//       } 
//       else 
//       {
//         Console.WriteLine("Good evening.");
//       }
//     }
//   }
// }