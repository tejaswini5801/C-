// using System;

// namespace Application
// {
//   class IfElse
//   {
//     static void Main(string[] args)
//     {
//       int x = 20;
//       int y = 18;
//       if (x > y)
//       {
//         Console.WriteLine("x is greater than y");
//       }
//     }
//   }
// }